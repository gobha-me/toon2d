Completed in [out/index.html](/evals/evals/g1-codex-1/out/index.html).

Passed **15/15 skill checks** and **11/11 additional checks**. Captures were inspected and independently reviewed. Decisions, rubric scores, and limitations are in [out/NOTES.md](/evals/evals/g1-codex-1/out/NOTES.md).

To play:

```sh
python3 -m http.server 8080 --directory out
```

Open `http://localhost:8080`.